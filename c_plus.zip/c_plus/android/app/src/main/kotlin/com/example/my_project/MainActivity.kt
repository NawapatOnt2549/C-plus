package com.mycompany.cplus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
